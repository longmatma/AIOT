#!/bin/bash
set -e

SERVICE_NAME="rbs-gateway.service"
SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
SERVICE_SRC="$SRC_DIR/$SERVICE_NAME"
SERVICE_DST="/etc/systemd/system/$SERVICE_NAME"
GATEWAY="/home/admin/rbs_gateway.py"

echo "===================================================="
echo " CAI TU DONG KHOI DONG rBS LoRa Gateway"
echo "===================================================="

if [ ! -f "$GATEWAY" ]; then
    echo "[LOI] Khong tim thay: $GATEWAY"
    echo "Hay dam bao file rbs_gateway.py nam tai /home/admin/rbs_gateway.py"
    exit 1
fi

if [ ! -f "$SERVICE_SRC" ]; then
    echo "[LOI] Khong tim thay file service: $SERVICE_SRC"
    exit 1
fi

echo "[1/5] Copy service -> $SERVICE_DST"
sudo cp "$SERVICE_SRC" "$SERVICE_DST"
sudo chmod 644 "$SERVICE_DST"

echo "[2/5] Nap lai systemd"
sudo systemctl daemon-reload

echo "[3/5] Bat tu dong khoi dong cung Raspberry Pi"
sudo systemctl enable "$SERVICE_NAME"

echo "[4/5] Khoi dong service ngay bay gio"
sudo systemctl restart "$SERVICE_NAME"

echo "[5/5] Kiem tra trang thai"
sleep 2
sudo systemctl --no-pager --full status "$SERVICE_NAME" || true

echo
echo "===================================================="
echo " HOAN TAT"
echo "===================================================="
echo "Xem log truc tiep:"
echo "  journalctl -u $SERVICE_NAME -f"
echo
echo "Thu reboot:"
echo "  sudo reboot"
