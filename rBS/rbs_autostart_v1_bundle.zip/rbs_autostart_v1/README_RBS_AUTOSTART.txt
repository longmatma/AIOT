RBS AUTOSTART V1
================

MUC TIEU
--------
Sau khi cai 1 lan:
  Cap nguon Raspberry Pi
      -> Pi boot
      -> systemd tu chay /home/admin/rbs_gateway.py
      -> rBS khoi tao LoRa va hoat dong

Khong can Wi-Fi, SSH, man hinh, ban phim, hay go:
  python3 rbs_gateway.py

CAI DAT
-------
1. Copy thu muc rbs_autostart_v1 vao Raspberry Pi.
2. cd rbs_autostart_v1
3. chmod +x install_rbs_autostart.sh
4. ./install_rbs_autostart.sh
5. Thu reboot:
   sudo reboot

KIEM TRA
--------
Trang thai:
  systemctl status rbs-gateway.service

Log realtime:
  journalctl -u rbs-gateway.service -f

100 dong log gan nhat:
  journalctl -u rbs-gateway.service -n 100 --no-pager

Khoi dong lai:
  sudo systemctl restart rbs-gateway.service

Dung:
  sudo systemctl stop rbs-gateway.service

Chay:
  sudo systemctl start rbs-gateway.service

Tat tu dong khoi dong:
  sudo systemctl disable rbs-gateway.service

Bat lai tu dong khoi dong:
  sudo systemctl enable rbs-gateway.service

GO CAI DAT
----------
sudo systemctl disable --now rbs-gateway.service
sudo rm /etc/systemd/system/rbs-gateway.service
sudo systemctl daemon-reload

LUU Y
-----
- Service khong phu thuoc Wi-Fi/network.
- SPI phai duoc bat nhu hien tai.
- User admin phai co quyen GPIO/SPI nhu khi chay python3 rbs_gateway.py.
- Neu Python crash, systemd tu restart sau 2 giay.
- Sau reboot, neu log co:
    [rBS] Khoi tao LoRa THANH CONG
    [rBS] PHA 1 -> DANG NGHE SU
  thi autostart hoat dong dung.
